package com.careerpath.repository;
import com.careerpath.entity.CareerSkill;
import org.springframework.data.jpa.repository.JpaRepository;
public interface CareerSkillRepository extends JpaRepository<CareerSkill,Long> { java.util.List<CareerSkill> findByCareerId(Long id); }
