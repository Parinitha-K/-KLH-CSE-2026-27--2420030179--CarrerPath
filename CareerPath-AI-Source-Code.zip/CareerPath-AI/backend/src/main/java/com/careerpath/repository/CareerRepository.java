package com.careerpath.repository;
import com.careerpath.entity.Career;
import org.springframework.data.jpa.repository.JpaRepository;
public interface CareerRepository extends JpaRepository<Career,Long> { java.util.Optional<Career> findByName(String name); }
