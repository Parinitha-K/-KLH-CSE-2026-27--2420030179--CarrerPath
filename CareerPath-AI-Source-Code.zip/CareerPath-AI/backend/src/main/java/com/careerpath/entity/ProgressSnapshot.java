package com.careerpath.entity;
import jakarta.persistence.*;
@Entity
public class ProgressSnapshot {
 @Id @GeneratedValue(strategy=GenerationType.IDENTITY) public Long id;
 @ManyToOne(optional=false) @com.fasterxml.jackson.annotation.JsonIgnore public User user;
 @ManyToOne(optional=false) @com.fasterxml.jackson.annotation.JsonIgnore public Roadmap roadmap;
 public java.time.Instant date; public int percentage;
}
