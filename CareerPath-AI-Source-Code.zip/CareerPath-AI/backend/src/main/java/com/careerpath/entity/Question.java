package com.careerpath.entity;
import jakarta.persistence.*;
@Entity
public class Question {
 @Id @GeneratedValue(strategy=GenerationType.IDENTITY) public Long id;
 @Column(length=1000) public String question;
 public String optionA; public String optionB; public String optionC; public String optionD;
 @com.fasterxml.jackson.annotation.JsonIgnore public String correctAnswer;
 public String category;
}
