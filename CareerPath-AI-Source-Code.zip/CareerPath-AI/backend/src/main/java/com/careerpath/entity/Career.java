package com.careerpath.entity;
import jakarta.persistence.*;
@Entity
public class Career {
 @Id @GeneratedValue(strategy=GenerationType.IDENTITY) public Long id;
 @Column(unique=true,nullable=false) public String name;
 @Column(length=2000) public String description;
 public String technologies; public String topics; public String interest;
}
