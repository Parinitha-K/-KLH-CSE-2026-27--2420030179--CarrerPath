package com.careerpath.repository;
import com.careerpath.entity.UserSkill;
import org.springframework.data.jpa.repository.JpaRepository;
public interface UserSkillRepository extends JpaRepository<UserSkill,Long> { java.util.List<UserSkill> findByUserId(Long id); java.util.Optional<UserSkill> findByUserIdAndSkillId(Long userId, Long skillId); }
