package com.careerpath.dto;
import jakarta.validation.constraints.*;
import java.util.Map;
import com.careerpath.entity.RoadmapItem.Status;
public class Requests {
 public record Register(@NotBlank @Size(max=100) String name,@NotBlank @Email @Size(max=200) String email,@NotBlank @Size(min=8,max=72) String password,@NotBlank @Size(max=200) String college,@Min(1) @Max(5) int year) {}
 public record Login(@NotBlank @Email String email,@NotBlank String password) {}
 public record Profile(@NotBlank @Size(max=100) String name,@NotBlank @Email @Size(max=200) String email,@NotBlank @Size(max=200) String college,@NotBlank @Size(max=100) String branch,@Min(1) @Max(5) int year,@NotNull @Size(max=500) String interests,@NotNull @Size(max=200) String careerGoal) {}
 public record SkillInput(@NotNull Long skillId,@Min(0) @Max(100) int level) {}
 public record Level(@Min(0) @Max(100) int level) {}
 public record Answers(@NotEmpty Map<Long,@Pattern(regexp="[ABCD]") String> answers) {}
 public record CreateRoadmap(@NotNull Long careerId) {}
 public record ItemStatus(@NotNull Status status) {}
}
