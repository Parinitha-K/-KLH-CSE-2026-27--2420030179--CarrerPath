package com.careerpath.repository;
import com.careerpath.entity.Question;
import org.springframework.data.jpa.repository.JpaRepository;
public interface QuestionRepository extends JpaRepository<Question,Long> {  }
