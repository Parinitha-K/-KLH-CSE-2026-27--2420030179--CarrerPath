package com.careerpath.entity;
import jakarta.persistence.*;
@Entity
public class Assessment {
 @Id @GeneratedValue(strategy=GenerationType.IDENTITY) public Long id;
 @ManyToOne(optional=false) @com.fasterxml.jackson.annotation.JsonIgnore public User user;
 public int score; public int total; public int percentage; public java.time.Instant date;
 @ElementCollection(fetch=FetchType.EAGER) @MapKeyColumn(name="category") @Column(name="percentage") public java.util.Map<String,Integer> categories = new java.util.LinkedHashMap<>();
}
