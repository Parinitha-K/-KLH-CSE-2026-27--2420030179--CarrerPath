package com.careerpath.repository;
import com.careerpath.entity.Roadmap;
import org.springframework.data.jpa.repository.JpaRepository;
public interface RoadmapRepository extends JpaRepository<Roadmap,Long> { java.util.List<Roadmap> findByUserIdOrderByCreatedAtDesc(Long id); java.util.Optional<Roadmap> findByUserIdAndCareerId(Long userId,Long careerId); }
