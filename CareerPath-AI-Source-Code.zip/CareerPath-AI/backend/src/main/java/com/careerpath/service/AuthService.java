package com.careerpath.service;
import com.careerpath.dto.Requests.*;
import com.careerpath.entity.User;
import com.careerpath.repository.UserRepository;
import com.careerpath.security.JwtService;
import com.careerpath.exception.ApiException;
import org.springframework.http.HttpStatus;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.util.*;
@Service
public class AuthService {
 private final UserRepository users;private final PasswordEncoder encoder;private final JwtService jwt;
 public AuthService(UserRepository users,PasswordEncoder encoder,JwtService jwt){this.users=users;this.encoder=encoder;this.jwt=jwt;}
 public String email(String email){return email.trim().toLowerCase(Locale.ROOT);}
 @Transactional public Map<String,Object> register(Register r){
  if(users.existsByEmail(email(r.email())))throw new ApiException(HttpStatus.CONFLICT,"An account with that email already exists.");
  User u=new User();u.name=r.name().trim();u.email=email(r.email());u.password=encoder.encode(r.password());u.college=r.college().trim();u.year=r.year();users.save(u);return session(u);
 }
 public Map<String,Object> login(Login r){User u=users.findByEmail(email(r.email())).orElseThrow(()->new ApiException(HttpStatus.UNAUTHORIZED,"Email or password is incorrect."));if(!encoder.matches(r.password(),u.password))throw new ApiException(HttpStatus.UNAUTHORIZED,"Email or password is incorrect.");return session(u);}
 private Map<String,Object> session(User u){return Map.of("token",jwt.issue(u.id),"user",u);}
 public User user(Long id){return users.findById(id).orElseThrow(()->ApiException.missing("User"));}
 @Transactional public User profile(Long id,Profile r){User u=user(id);users.findByEmail(email(r.email())).filter(other->!other.id.equals(id)).ifPresent(other->{throw new ApiException(HttpStatus.CONFLICT,"That email belongs to another account.");});u.name=r.name().trim();u.email=email(r.email());u.college=r.college().trim();u.branch=r.branch().trim();u.year=r.year();u.interests=r.interests().trim();u.careerGoal=r.careerGoal().trim();return users.save(u);}
}
