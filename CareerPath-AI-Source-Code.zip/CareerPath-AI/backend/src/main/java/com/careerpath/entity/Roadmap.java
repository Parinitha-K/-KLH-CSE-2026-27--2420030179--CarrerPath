package com.careerpath.entity;
import jakarta.persistence.*;
@Entity
@Table(uniqueConstraints=@UniqueConstraint(columnNames={"user_id","career_id"}))
public class Roadmap {
 @Id @GeneratedValue(strategy=GenerationType.IDENTITY) public Long id;
 @ManyToOne(optional=false) @JoinColumn(name="user_id") @com.fasterxml.jackson.annotation.JsonIgnore public User user;
 @ManyToOne(optional=false) @JoinColumn(name="career_id") public Career career;
 public int progress; public java.time.Instant createdAt;
 @OneToMany(mappedBy="roadmap",cascade=CascadeType.ALL,orphanRemoval=true,fetch=FetchType.EAGER) @OrderBy("orderNumber ASC") public java.util.List<RoadmapItem> items = new java.util.ArrayList<>();
}
