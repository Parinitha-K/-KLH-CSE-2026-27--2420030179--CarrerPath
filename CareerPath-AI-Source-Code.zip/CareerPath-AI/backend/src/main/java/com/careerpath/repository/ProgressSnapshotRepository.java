package com.careerpath.repository;
import com.careerpath.entity.ProgressSnapshot;
import org.springframework.data.jpa.repository.JpaRepository;
public interface ProgressSnapshotRepository extends JpaRepository<ProgressSnapshot,Long> { java.util.List<ProgressSnapshot> findByUserIdAndRoadmapIdOrderByDateAsc(Long userId,Long roadmapId); }
